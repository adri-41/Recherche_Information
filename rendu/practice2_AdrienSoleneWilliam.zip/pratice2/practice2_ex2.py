import re
import gzip
import os
import matplotlib.pyplot as plt


def read_documents(text):
    pattern = re.compile(r"<doc>\s*<docno>\s*([^<\s]+)\s*</docno>(.*?)</doc>",
                         flags=re.IGNORECASE | re.DOTALL)
    docs = []
    for m in pattern.finditer(text):
        doc_id = m.group(1).strip()
        contained = m.group(2)
        docs.append((doc_id, contained))
    return docs

def tokeniser(text) :
    t = text.lower()
    t = t.replace("’", " ").replace("‘", " ").replace("`", " ")
    return re.findall(r"[a-z]+", t)

def build_stats(docs):
    total_terms = 0
    total_chars = 0
    vocab = set()

    for doc_id, contained in docs:
        tokens = tokeniser(contained)
        total_terms += len(tokens)
        total_chars += sum(len(w) for w in tokens)
        vocab.update(tokens)

    avg_doc_length = total_terms / len(docs) if docs else 0
    avg_term_length = total_chars / total_terms if total_terms else 0
    vocab_size = len(vocab)

    return avg_doc_length, avg_term_length, vocab_size

def read_file(path):
    if path.endswith(".gz"):
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return f.read()
    else:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()


def main():
    data_dir = os.path.join(os.getcwd(), "Practice_02_data")
    if not os.path.isdir(data_dir):
        print(f"Dossier introuvable : {data_dir}")
        return

    files = sorted([os.path.join(data_dir, f) for f in os.listdir(data_dir) if f.endswith(".gz")])

    sizes = []
    avg_doc_lengths = []
    avg_term_lengths = []
    vocab_sizes = []

    for path in files:
        print(f"Traitement de {os.path.basename(path)}...")
        file_size_kb = os.path.getsize(path) / 1024
        sizes.append(file_size_kb)

        text = read_file(path)
        docs = read_documents(text)
        avg_doc, avg_term, vocab_size = build_stats(docs)

        avg_doc_lengths.append(avg_doc)
        avg_term_lengths.append(avg_term)
        vocab_sizes.append(vocab_size)

        print(f"Taille: {file_size_kb:.0f} KB | Avg doc length: {avg_doc:.2f} | "
              f"Avg term length: {avg_term:.2f} | Vocab size: {vocab_size}")

    # --- Tracer 3 sous-graphes ---
    plt.figure(figsize=(15, 4))

    plt.subplot(1, 3, 1)
    plt.plot(sizes, avg_doc_lengths, marker="o")
    plt.xlabel("Taille fichier (KB)")
    plt.ylabel("nombre moyen de termes par document dans ce fichier")
    plt.title("1. longueur moyenne des documents")
    plt.grid(True)

    plt.subplot(1, 3, 2)
    plt.plot(sizes, avg_term_lengths, marker="s", color="orange")
    plt.xlabel("Taille fichier (KB)")
    plt.ylabel("nombre moyen de caractères par terme")
    plt.title("2. longueur moyenne des termes")
    plt.grid(True)

    plt.subplot(1, 3, 3)
    plt.plot(sizes, vocab_sizes, marker="^", color="green")
    plt.xlabel("Taille fichier (KB)")
    plt.ylabel("nombre de termes distincts dans le fichier")
    plt.title("3. taille du vocabulaire")
    plt.grid(True)

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
