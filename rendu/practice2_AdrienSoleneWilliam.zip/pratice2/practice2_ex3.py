import re
import gzip
import os
import matplotlib.pyplot as plt

def read_documents(text):
    pattern = re.compile(r"<doc>\s*<docno>\s*([^<\s]+)\s*</docno>(.*?)</doc>",
                         flags=re.IGNORECASE | re.DOTALL)
    docs = []
    for m in pattern.finditer(text):
        doc_id = m.group(1).strip()
        contained = m.group(2)
        docs.append((doc_id, contained))
    return docs

def read_file(path):
    if path.endswith(".gz"):
        with gzip.open(path, "rt", encoding="utf-8", errors="ignore") as f:
            return f.read()
    else:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
        
def tokeniser(text):
    t = text.lower().replace("’", " ").replace("‘", " ").replace("`", " ")
    return re.findall(r"[a-z]+", t)

def load_stopwords(path):
    stop = set()
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip().lower()
            if s and not s.startswith("#"):
                stop.add(s)
    return stop

def tokeniser_stopwords(text, stopset):
    toks = tokeniser(text)
    if not stopset:
        return toks
    return [t for t in toks if t not in stopset]

def build_stats(docs, tokenizer):
    total_terms = 0
    total_chars = 0
    vocab = set()
    for _, contained in docs:
        tokens = tokenizer(contained)
        total_terms += len(tokens)
        total_chars += sum(len(w) for w in tokens)
        vocab.update(tokens)
    avg_doc_length = total_terms / len(docs) if docs else 0.0
    avg_term_length = total_chars / total_terms if total_terms else 0.0
    vocab_size = len(vocab)
    return avg_doc_length, avg_term_length, vocab_size, total_terms, len(docs)


def main():
    data_dir = os.path.join(os.getcwd(), "Practice_02_data")
    stop_path = os.path.join(data_dir, "stop-words-english4.txt")

    if not os.path.isdir(data_dir):
        print(f"Dossier introuvable : {data_dir}")
        return
    if not os.path.exists(stop_path):
        print(f"Fichier stop-words introuvable : {stop_path}")
        return

    files = sorted([os.path.join(data_dir, f)
                    for f in os.listdir(data_dir) if f.endswith(".gz")])
    if not files:
        print("Aucun fichier .gz trouvé dans", data_dir)
        return

    stopset = load_stopwords(stop_path)

    file9 = next((p for p in files if os.path.basename(p).startswith("09-")), None)
    text9 = read_file(file9)
    docs9 = read_documents(text9)

    avg_doc_b, avg_term_b, vocab_b, tokens_b, ndocs_b = build_stats(docs9, tokeniser)
    avg_doc_s, avg_term_s, vocab_s, tokens_s, ndocs_s = build_stats(docs9, lambda t: tokeniser_stopwords(t, stopset))

    print(f"  avg doc length (#terms) : {avg_doc_b:.2f}")
    print(f"  avg term length (#chars): {avg_term_b:.2f}")
    print(f"  vocabulary size         : {vocab_b}")
    print(f"  total tokens            : {tokens_b}")
    print("Avec stop-words :")
    print(f"  avg doc length (#terms) : {avg_doc_s:.2f}")
    print(f"  avg term length (#chars): {avg_term_s:.2f}")
    print(f"  vocabulary size         : {vocab_s}")
    print(f"  total tokens            : {tokens_s}")

    print("\nÉvolution cumulative (avec stop-words)")

    cum_total_terms = 0
    cum_total_chars = 0
    cum_num_docs = 0
    cum_vocab = set()

    x_tokens = []           
    avg_doc_lengths = []    
    avg_term_lengths = []  
    vocab_sizes = []        

    for path in files:
        print(f"Traitement de {os.path.basename(path)}...")
        text = read_file(path)
        docs = read_documents(text)

        file_vocab = set()
        for _, content in docs:
            toks = tokeniser_stopwords(content, stopset)
            cum_total_terms += len(toks)
            cum_total_chars += sum(len(w) for w in toks)
            file_vocab.update(toks)
        cum_vocab |= file_vocab
        cum_num_docs += len(docs)

        avg_doc = (cum_total_terms / cum_num_docs) if cum_num_docs else 0.0
        avg_term = (cum_total_chars / cum_total_terms) if cum_total_terms else 0.0
        vsize = len(cum_vocab)

        x_tokens.append(cum_total_terms)
        avg_doc_lengths.append(avg_doc)
        avg_term_lengths.append(avg_term)
        vocab_sizes.append(vsize)

        print(f"  cumul => tokens={cum_total_terms}, docs={cum_num_docs}, "
              f"avg_doc_len={avg_doc:.2f}, avg_term_len={avg_term:.2f}, vocab={vsize}")

    plt.figure(figsize=(15, 4))

    plt.subplot(1, 3, 1)
    plt.plot(x_tokens, avg_doc_lengths, marker="o")
    plt.xlabel("Taille de la collection (#tokens cumulés)")
    plt.ylabel("Longueur moyenne des documents (#termes)")
    plt.title("1. Avg doc length (stop-words)")
    plt.grid(True)

    plt.subplot(1, 3, 2)
    plt.plot(x_tokens, avg_term_lengths, marker="o")
    plt.xlabel("Taille de la collection (#tokens cumulés)")
    plt.ylabel("Longueur moyenne des termes (#caractères)")
    plt.title("2. Avg term length (stop-words)")
    plt.grid(True)

    plt.subplot(1, 3, 3)
    plt.plot(x_tokens, vocab_sizes, marker="o")
    plt.xlabel("Taille de la collection (#tokens cumulés)")
    plt.ylabel("Taille du vocabulaire (#termes distincts)")
    plt.title("3. Vocabulary size (stop-words)")
    plt.grid(True)

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()